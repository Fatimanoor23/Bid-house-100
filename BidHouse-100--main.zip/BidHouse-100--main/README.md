# BidHouse-100-
Our final year project 100% implentation code.
